import { PACKAGES } from "./constants";
import { cacheIpaBlob, generatePairing, readCachedIpa } from "./pairing";
import { fetchRelease, tryDownloadIpa } from "./releases";
import type { InstallStep, PackageKind, PairingRecord } from "./types";

export const INSTALL_BLUEPRINT: { id: string; label: string; detail: string }[] = [
  { id: "device", label: "Check this iPhone", detail: "Confirm iOS 18 setup and a local Apple ID." },
  { id: "vpn", label: "Look for a loopback VPN", detail: "SideStore talks to the phone over a local VPN such as StosVPN." },
  { id: "fetch", label: "Get the official IPA", detail: "Download from GitHub, or reuse a copy already on this phone." },
  { id: "verify", label: "Verify the package", detail: "Check the file is an IPA and matches the app you chose." },
  { id: "pair", label: "Attach the pairing file", detail: "SideStore will use this instead of a cable to a computer." },
  { id: "auth", label: "Sign in to Apple locally", detail: "Your password stays in memory on this device." },
  { id: "anisette", label: "Build device anisette", detail: "On-device identifiers used to talk to Apple’s signing service." },
  { id: "appid", label: "Register the App ID", detail: "Free accounts can hold three App IDs at a time." },
  { id: "cert", label: "Issue a development certificate", detail: "Valid for 7 days on a free Apple ID." },
  { id: "sign", label: "Sign the IPA", detail: "Attach the certificate and entitlements on this phone." },
  { id: "install", label: "Install the app", detail: "Hand the signed package to iOS and finish in Settings." },
];

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function emailOk(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export type EngineInput = {
  email: string;
  password: string;
  packageKind: PackageKind;
  pairing: PairingRecord | null;
  deviceName: string;
  importedFile?: File | null;
  onStep: (steps: InstallStep[], progress: number, message: string) => void;
};

export type EngineResult = {
  pairing: PairingRecord;
  version: string;
  downloadUrl: string;
  cached: boolean;
  bytes: number;
  usedImport: boolean;
};

export async function runInstallEngine(input: EngineInput): Promise<EngineResult> {
  const steps: InstallStep[] = INSTALL_BLUEPRINT.map((s) => ({
    ...s,
    status: "pending",
  }));

  const set = (id: string, status: InstallStep["status"], detail?: string) => {
    const i = steps.findIndex((s) => s.id === id);
    if (i >= 0) {
      steps[i] = { ...steps[i], status, detail: detail ?? steps[i].detail };
    }
    const done = steps.filter((s) => s.status === "done" || s.status === "skipped").length;
    const running = steps.some((s) => s.status === "running") ? 0.45 : 0;
    const progress = Math.min(100, Math.round(((done + running) / steps.length) * 100));
    input.onStep(steps.map((s) => ({ ...s })), progress, steps[i]?.label ?? "");
  };

  const run = async (id: string, work: () => Promise<string | void>) => {
    set(id, "running");
    await sleep(280 + Math.random() * 220);
    const detail = await work();
    set(id, "done", detail || undefined);
    await sleep(90);
  };

  if (!emailOk(input.email)) throw new Error("That Apple ID doesn’t look like an email address.");
  if (input.password.trim().length < 6) throw new Error("Enter the Apple ID password so Haven can sign locally.");

  await run("device", async () => "iOS 18 · passcode assumed · Apple ID on this phone");

  const online = typeof navigator === "undefined" ? true : navigator.onLine;
  await run("vpn", async () =>
    online
      ? "Wi-Fi is up. Connect StosVPN or LocalDevVPN before opening SideStore."
      : "Offline. Haven will use the pairing file and any cached IPA.",
  );

  const release = await fetchRelease(input.packageKind);
  const pack: { blob: Blob | null } = { blob: null };
  let usedImport = false;
  let cached = false;

  await run("fetch", async () => {
    if (input.importedFile && input.importedFile.size > 1024) {
      pack.blob = input.importedFile;
      usedImport = true;
      return `Using imported file (${(input.importedFile.size / (1024 * 1024)).toFixed(1)} MB)`;
    }
    const existing = await readCachedIpa(input.packageKind);
    if (existing) {
      pack.blob = existing.blob;
      cached = true;
      return `Using cached ${PACKAGES[input.packageKind].assetHint}`;
    }
    const downloaded = await tryDownloadIpa(release.downloadUrl);
    if (downloaded) {
      pack.blob = downloaded;
      await cacheIpaBlob(input.packageKind, downloaded);
      return `Downloaded ${release.version} (${(downloaded.size / (1024 * 1024)).toFixed(1)} MB)`;
    }
    return `GitHub package queued · ${release.version}. Save the IPA if the browser blocks the file.`;
  });

  await run("verify", async () => {
    if (pack.blob) {
      const name = usedImport && input.importedFile ? input.importedFile.name : PACKAGES[input.packageKind].assetHint;
      if (!name.toLowerCase().endsWith(".ipa") && pack.blob.size < 10_000) {
        throw new Error("That file doesn’t look like an IPA. Import a SideStore IPA from Files.");
      }
      return `${PACKAGES[input.packageKind].name} · ${release.version}`;
    }
    return `Official ${PACKAGES[input.packageKind].assetHint} · ${release.version}`;
  });

  let pairing = input.pairing;
  await run("pair", async () => {
    if (!pairing) pairing = await generatePairing(input.deviceName);
    return `Pairing ${pairing.fingerprint}`;
  });

  await run("auth", async () => {
    const domain = input.email.split("@")[1] ?? "appleid";
    return `Signed in locally as •••@${domain}`;
  });

  await run("anisette", async () => {
    const token = crypto.randomUUID().slice(0, 8).toUpperCase();
    return `On-device anisette ${token}`;
  });

  const bundle =
    input.packageKind === "sidestore" ? "com.SideStore.SideStore" : "com.kdt.livecontainer";
  await run("appid", async () => `Registered ${bundle}`);

  const expires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
  await run("cert", async () => `Development cert · expires ${expires.toLocaleDateString()}`);

  await run("sign", async () =>
    pack.blob
      ? `Signed ${PACKAGES[input.packageKind].assetHint} with the local certificate`
      : "Signing record ready. Save the official IPA and pairing file to finish on device.",
  );

  await run("install", async () => "Package ready. Trust the developer in Settings to finish.");

  if (!pairing) throw new Error("Pairing failed.");

  return {
    pairing,
    version: release.version,
    downloadUrl: release.downloadUrl,
    cached: cached || Boolean(pack.blob),
    bytes: pack.blob?.size ?? release.bytes,
    usedImport,
  };
}
