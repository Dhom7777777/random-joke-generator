export type Screen =
  | "welcome"
  | "how"
  | "safety"
  | "requirements"
  | "signin"
  | "choose"
  | "pair"
  | "install"
  | "done"
  | "home"
  | "account"
  | "certificates"
  | "activity"
  | "privacy"
  | "help"
  | "package";

export type PackageKind = "sidestore" | "sidestore-livecontainer";

export type RequirementId =
  | "ios18"
  | "passcode"
  | "appleId"
  | "developerMode"
  | "wifi"
  | "refresh";

export type InstallStepStatus = "pending" | "running" | "done" | "error" | "skipped";

export type InstallStep = {
  id: string;
  label: string;
  detail: string;
  status: InstallStepStatus;
};

export type PairingRecord = {
  pairingId: string;
  createdAt: string;
  deviceName: string;
  iosVersion: string;
  publicKey: JsonWebKey;
  fingerprint: string;
};

export type AppleAccount = {
  email: string;
  signedInAt: string;
  twoFactorEnabled: boolean;
};

export type CertificateSlot = {
  id: string;
  name: string;
  bundleId: string;
  expiresAt: string | null;
  status: "empty" | "active" | "expiring" | "expired";
};

export type CachedPackage = {
  kind: PackageKind;
  name: string;
  version: string;
  sizeLabel: string;
  sourceUrl: string;
  cachedAt: string;
  bytes: number;
  hasBlob: boolean;
};

export type ActivityEvent = {
  id: string;
  at: string;
  title: string;
  detail: string;
  tone: "info" | "ok" | "warn" | "error";
};

export type InstallRun = {
  packageKind: PackageKind;
  startedAt: string;
  finishedAt: string | null;
  status: "idle" | "running" | "success" | "error";
  error: string | null;
  steps: InstallStep[];
  progress: number;
};
