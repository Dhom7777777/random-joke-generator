import { OFFICIAL_LINKS, PACKAGES } from "./constants";
import type { PackageKind } from "./types";

export type ReleaseInfo = {
  kind: PackageKind;
  version: string;
  name: string;
  sizeLabel: string;
  bytes: number;
  downloadUrl: string;
  publishedAt: string | null;
};

type GithubRelease = {
  tag_name?: string;
  name?: string;
  published_at?: string;
  assets?: {
    name: string;
    browser_download_url: string;
    size: number;
  }[];
};

function formatBytes(n: number) {
  if (!n) return "Unknown size";
  if (n < 1024 * 1024) return `${Math.max(1, Math.round(n / 1024))} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function pickAsset(kind: PackageKind, assets: GithubRelease["assets"]) {
  const hint = PACKAGES[kind].assetHint.toLowerCase();
  const list = assets ?? [];
  const exact = list.find((a) => a.name.toLowerCase() === hint);
  if (exact) return exact;
  const ipa = list.find((a) => a.name.toLowerCase().endsWith(".ipa") && a.name.toLowerCase().includes(hint.replace(".ipa", "")));
  if (ipa) return ipa;
  return list.find((a) => a.name.toLowerCase().endsWith(".ipa"));
}

export async function fetchRelease(kind: PackageKind): Promise<ReleaseInfo> {
  const pkg = PACKAGES[kind];
  const fallbackUrl = kind === "sidestore" ? OFFICIAL_LINKS.sidestoreIpa : OFFICIAL_LINKS.livecontainerIpa;
  try {
    const res = await fetch(`https://api.github.com/repos/${pkg.repo}/releases/latest`, {
      headers: { Accept: "application/vnd.github+json" },
    });
    if (!res.ok) throw new Error(`GitHub ${res.status}`);
    const json = (await res.json()) as GithubRelease;
    const asset = pickAsset(kind, json.assets);
    return {
      kind,
      version: json.tag_name || json.name || "latest",
      name: pkg.name,
      bytes: asset?.size ?? 0,
      sizeLabel: formatBytes(asset?.size ?? 0),
      downloadUrl: asset?.browser_download_url || fallbackUrl,
      publishedAt: json.published_at ?? null,
    };
  } catch {
    return {
      kind,
      version: "latest",
      name: pkg.name,
      bytes: 0,
      sizeLabel: "Download on demand",
      downloadUrl: fallbackUrl,
      publishedAt: null,
    };
  }
}

export async function tryDownloadIpa(url: string): Promise<Blob | null> {
  try {
    const res = await fetch(url, { mode: "cors" });
    if (!res.ok) return null;
    const blob = await res.blob();
    if (blob.size < 1024) return null;
    return blob;
  } catch {
    return null;
  }
}
