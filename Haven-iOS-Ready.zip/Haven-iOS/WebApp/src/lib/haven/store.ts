import { create } from "zustand";
import { persist } from "zustand/middleware";
import { PACKAGES, STORAGE_KEY } from "./constants";
import { runInstallEngine } from "./engine";
import { generatePairing } from "./pairing";
import type {
  ActivityEvent,
  AppleAccount,
  CachedPackage,
  CertificateSlot,
  InstallRun,
  PackageKind,
  PairingRecord,
  RequirementId,
  Screen,
} from "./types";

const EMPTY_SLOTS: CertificateSlot[] = [
  { id: "slot-1", name: "Empty slot", bundleId: "", expiresAt: null, status: "empty" },
  { id: "slot-2", name: "Empty slot", bundleId: "", expiresAt: null, status: "empty" },
  { id: "slot-3", name: "Empty slot", bundleId: "", expiresAt: null, status: "empty" },
];

type SessionSecrets = {
  password: string;
  twoFactor: string;
};

const secrets: SessionSecrets = { password: "", twoFactor: "" };

function uid() {
  return crypto.randomUUID();
}

function nowIso() {
  return new Date().toISOString();
}

type HavenState = {
  screen: Screen;
  history: Screen[];
  setupComplete: boolean;
  requirements: Record<RequirementId, boolean>;
  account: AppleAccount | null;
  packageKind: PackageKind;
  pairing: PairingRecord | null;
  certificates: CertificateSlot[];
  packages: CachedPackage[];
  activity: ActivityEvent[];
  install: InstallRun;
  importedFileName: string | null;
  deviceName: string;
  go: (screen: Screen) => void;
  back: () => void;
  toggleRequirement: (id: RequirementId) => void;
  setAccountEmail: (email: string, twoFactorEnabled: boolean) => void;
  setPassword: (password: string) => void;
  setTwoFactor: (code: string) => void;
  forgetAccount: () => void;
  setPackageKind: (kind: PackageKind) => void;
  setImportedFile: (file: File | null) => void;
  pairDevice: () => Promise<void>;
  startInstall: () => Promise<void>;
  resetInstall: () => void;
  log: (title: string, detail: string, tone?: ActivityEvent["tone"]) => void;
};

const importedRef: { file: File | null } = { file: null };

const idleInstall = (kind: PackageKind): InstallRun => ({
  packageKind: kind,
  startedAt: "",
  finishedAt: null,
  status: "idle",
  error: null,
  steps: [],
  progress: 0,
});

export const useHaven = create<HavenState>()(
  persist(
    (set, get) => ({
      screen: "welcome",
      history: [],
      setupComplete: false,
      requirements: {
        ios18: false,
        passcode: false,
        appleId: false,
        developerMode: false,
        wifi: false,
        refresh: false,
      },
      account: null,
      packageKind: "sidestore-livecontainer",
      pairing: null,
      certificates: EMPTY_SLOTS,
      packages: [],
      activity: [],
      install: idleInstall("sidestore-livecontainer"),
      importedFileName: null,
      deviceName: "iPhone",
      go: (screen) =>
        set((s) => ({
          screen,
          history: s.screen === screen ? s.history : [...s.history, s.screen].slice(-12),
        })),
      back: () =>
        set((s) => {
          const history = [...s.history];
          const prev = history.pop() ?? (s.setupComplete ? "home" : "welcome");
          return { screen: prev, history };
        }),
      toggleRequirement: (id) =>
        set((s) => ({ requirements: { ...s.requirements, [id]: !s.requirements[id] } })),
      setAccountEmail: (email, twoFactorEnabled) => {
        const trimmed = email.trim();
        set({
          account: {
            email: trimmed,
            signedInAt: nowIso(),
            twoFactorEnabled,
          },
        });
        get().log("Apple ID saved", "Stored on this iPhone only.", "ok");
      },
      setPassword: (password) => {
        secrets.password = password;
      },
      setTwoFactor: (code) => {
        secrets.twoFactor = code;
      },
      forgetAccount: () => {
        secrets.password = "";
        secrets.twoFactor = "";
        set({ account: null });
        get().log("Apple ID forgotten", "Email and session password were removed from this phone.", "warn");
      },
      setPackageKind: (kind) => set({ packageKind: kind }),
      setImportedFile: (file) => {
        importedRef.file = file;
        set({ importedFileName: file?.name ?? null });
      },
      pairDevice: async () => {
        const record = await generatePairing(get().deviceName);
        set({ pairing: record });
        get().log("iPhone paired", `Fingerprint ${record.fingerprint}`, "ok");
      },
      startInstall: async () => {
        const s = get();
        if (!s.account) throw new Error("Sign in with your Apple ID first.");
        if (!secrets.password) throw new Error("Enter your Apple ID password. It is not saved.");
        set({
          screen: "install",
          history: [...s.history, s.screen].slice(-12),
          install: {
            packageKind: s.packageKind,
            startedAt: nowIso(),
            finishedAt: null,
            status: "running",
            error: null,
            steps: [],
            progress: 0,
          },
        });
        get().log("Install started", PACKAGES[s.packageKind].name, "info");
        try {
          const result = await runInstallEngine({
            email: s.account.email,
            password: secrets.password,
            packageKind: s.packageKind,
            pairing: s.pairing,
            deviceName: s.deviceName,
            importedFile: importedRef.file,
            onStep: (steps, progress) =>
              set((cur) => ({
                install: { ...cur.install, steps, progress },
              })),
          });
          const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
          const slot: CertificateSlot = {
            id: "slot-1",
            name: PACKAGES[s.packageKind].name,
            bundleId:
              s.packageKind === "sidestore" ? "com.SideStore.SideStore" : "com.kdt.livecontainer",
            expiresAt,
            status: "active",
          };
          const cached: CachedPackage = {
            kind: s.packageKind,
            name: PACKAGES[s.packageKind].name,
            version: result.version,
            sizeLabel: result.bytes ? `${(result.bytes / (1024 * 1024)).toFixed(1)} MB` : "Official IPA",
            sourceUrl: result.downloadUrl,
            cachedAt: nowIso(),
            bytes: result.bytes,
            hasBlob: result.cached,
          };
          set((cur) => ({
            pairing: result.pairing,
            setupComplete: true,
            certificates: [slot, ...cur.certificates.filter((c) => c.id !== "slot-1")],
            packages: [cached, ...cur.packages.filter((p) => p.kind !== s.packageKind)],
            install: {
              ...cur.install,
              status: "success",
              finishedAt: nowIso(),
              progress: 100,
            },
            screen: "done",
          }));
          secrets.password = "";
          get().log("Install finished", `${PACKAGES[s.packageKind].name} ${result.version}`, "ok");
        } catch (err) {
          const message = err instanceof Error ? err.message : "Install failed.";
          set((cur) => ({
            install: {
              ...cur.install,
              status: "error",
              error: message,
              finishedAt: nowIso(),
            },
          }));
          get().log("Install failed", message, "error");
        }
      },
      resetInstall: () => set((s) => ({ install: idleInstall(s.packageKind) })),
      log: (title, detail, tone = "info") =>
        set((s) => ({
          activity: [
            { id: uid(), at: nowIso(), title, detail, tone },
            ...s.activity,
          ].slice(0, 80),
        })),
    }),
    {
      name: STORAGE_KEY,
      partialize: (s) => ({
        setupComplete: s.setupComplete,
        requirements: s.requirements,
        account: s.account,
        packageKind: s.packageKind,
        pairing: s.pairing,
        certificates: s.certificates,
        packages: s.packages,
        activity: s.activity,
        deviceName: s.deviceName,
        screen: s.setupComplete ? "home" : "welcome",
      }),
    },
  ),
);

export function getSessionPassword() {
  return secrets.password;
}
