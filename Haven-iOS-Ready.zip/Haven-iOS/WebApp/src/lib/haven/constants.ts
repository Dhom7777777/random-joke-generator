import type { PackageKind, RequirementId } from "./types";

export const APP_NAME = "Haven";
export const APP_TAGLINE = "Install SideStore on this iPhone. No computer.";
export const IOS_TARGET = "18";

export const STORAGE_KEY = "haven-v1";
export const IPA_DB = "haven-ipa";
export const IPA_STORE = "packages";
export const PAIRING_DB = "haven-keys";
export const PAIRING_STORE = "keys";

export const REQUIREMENTS: {
  id: RequirementId;
  title: string;
  body: string;
}[] = [
  {
    id: "ios18",
    title: "iOS 18 or later",
    body: "SideStore and LiveContainer need a recent iPhone or iPad. This setup is written for iOS 18.",
  },
  {
    id: "passcode",
    title: "A passcode is set",
    body: "Apple requires a device passcode before you can trust a developer app or turn on Developer Mode.",
  },
  {
    id: "appleId",
    title: "You know your Apple ID",
    body: "Haven uses it only on this phone to sign the app. A free Apple ID is enough.",
  },
  {
    id: "developerMode",
    title: "You can turn on Developer Mode",
    body: "Settings → Privacy & Security → Developer Mode. The phone restarts once.",
  },
  {
    id: "wifi",
    title: "Wi-Fi for the first setup",
    body: "Haven downloads SideStore once, then keeps a copy for offline installs. Pairing also needs Wi-Fi the first time.",
  },
  {
    id: "refresh",
    title: "You can refresh every 7 days",
    body: "Free developer apps expire after a week. SideStore can refresh itself on the phone after this setup.",
  },
];

export const PACKAGES: Record<
  PackageKind,
  {
    kind: PackageKind;
    name: string;
    short: string;
    description: string;
    slots: string;
    repo: string;
    assetHint: string;
  }
> = {
  sidestore: {
    kind: "sidestore",
    name: "SideStore",
    short: "SideStore only",
    description:
      "The classic sideloading app. Install IPA files and refresh them from your phone. Uses one of your three free app slots.",
    slots: "Uses 1 of 3 app slots",
    repo: "SideStore/SideStore",
    assetHint: "SideStore.ipa",
  },
  "sidestore-livecontainer": {
    kind: "sidestore-livecontainer",
    name: "SideStore + LiveContainer",
    short: "SideStore + LiveContainer",
    description:
      "One app that includes SideStore and LiveContainer. Run extra apps inside LiveContainer and keep two slots free.",
    slots: "Uses 1 slot for both",
    repo: "LiveContainer/LiveContainer",
    assetHint: "LiveContainer+SideStore.ipa",
  },
};

export const OFFICIAL_LINKS = {
  sidestore: "https://sidestore.io/",
  sidestoreDocs: "https://docs.sidestore.io/docs/installation/install",
  sidestoreReleases: "https://github.com/SideStore/SideStore/releases/latest",
  livecontainer: "https://github.com/LiveContainer/LiveContainer",
  livecontainerIpa:
    "https://github.com/LiveContainer/LiveContainer/releases/latest/download/LiveContainer+SideStore.ipa",
  sidestoreIpa:
    "https://github.com/SideStore/SideStore/releases/latest/download/SideStore.ipa",
  stosVpn: "https://github.com/Stossy11/StosVPN",
  localDevVpn: "https://github.com/SideStore/LocalDevVPN",
};

export const HOW_STEPS = [
  {
    n: "01",
    title: "Sign in locally",
    body: "Enter your Apple ID on this phone. Haven never creates an account and never uploads the password.",
  },
  {
    n: "02",
    title: "Pick what to install",
    body: "SideStore by itself, or SideStore plus LiveContainer in one app so you keep more free slots.",
  },
  {
    n: "03",
    title: "Pair and sign here",
    body: "Haven makes a pairing file on the phone, then signs the official IPA with your Apple ID.",
  },
  {
    n: "04",
    title: "Trust it once",
    body: "In Settings, trust the developer app and turn on Developer Mode. After that, SideStore refreshes itself.",
  },
];
