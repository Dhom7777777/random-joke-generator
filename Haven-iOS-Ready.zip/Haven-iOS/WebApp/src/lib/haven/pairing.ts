import { IPA_DB, IPA_STORE, PAIRING_DB, PAIRING_STORE } from "./constants";
import { idbGet, idbSet } from "./idb";
import type { PairingRecord } from "./types";

function bytesToHex(bytes: ArrayBuffer) {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function generatePairing(deviceName: string): Promise<PairingRecord> {
  const keypair = await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign", "verify"],
  );
  const publicKey = await crypto.subtle.exportKey("jwk", keypair.publicKey);
  const privateKey = await crypto.subtle.exportKey("jwk", keypair.privateKey);
  const pairingId = crypto.randomUUID();
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${pairingId}:${publicKey.x}:${publicKey.y}`),
  );
  const record: PairingRecord = {
    pairingId,
    createdAt: new Date().toISOString(),
    deviceName,
    iosVersion: "18",
    publicKey,
    fingerprint: bytesToHex(digest).slice(0, 16).toUpperCase(),
  };
  await idbSet(PAIRING_DB, PAIRING_STORE, "current", { record, privateKey });
  return record;
}

export async function loadStoredPairingPrivateKey(): Promise<JsonWebKey | undefined> {
  const stored = await idbGet<{ privateKey: JsonWebKey }>(PAIRING_DB, PAIRING_STORE, "current");
  return stored?.privateKey;
}

export function pairingFilePayload(record: PairingRecord, privateKey?: JsonWebKey) {
  return {
    format: "haven-pairing-v1",
    note: "Generated on-device by Haven. Import this into SideStore if asked for a pairing file.",
    pairingId: record.pairingId,
    createdAt: record.createdAt,
    deviceName: record.deviceName,
    iosVersion: record.iosVersion,
    fingerprint: record.fingerprint,
    publicKey: record.publicKey,
    privateKey: privateKey ?? null,
  };
}

export function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export async function cacheIpaBlob(kind: string, blob: Blob) {
  await idbSet(IPA_DB, IPA_STORE, kind, { blob, savedAt: Date.now(), size: blob.size });
}

export async function readCachedIpa(kind: string): Promise<{ blob: Blob; size: number } | undefined> {
  const stored = await idbGet<{ blob: Blob; size: number }>(IPA_DB, IPA_STORE, kind);
  if (!stored?.blob) return undefined;
  return { blob: stored.blob, size: stored.size ?? stored.blob.size };
}
