import {
  Check,
  Download,
  Eye,
  EyeOff,
  FileUp,
  LoaderCircle,
  Smartphone,
} from "lucide-react";
import { useState } from "react";
import { BottomBar, Group, NavBar, PrimaryButton, Row, ScreenBody } from "@/components/haven/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { OFFICIAL_LINKS, PACKAGES } from "@/lib/haven/constants";
import { downloadJson, loadStoredPairingPrivateKey, pairingFilePayload } from "@/lib/haven/pairing";
import { useHaven } from "@/lib/haven/store";
import type { PackageKind } from "@/lib/haven/types";
import { cn } from "@/lib/utils";

export function SignInScreen() {
  const go = useHaven((s) => s.go);
  const back = useHaven((s) => s.back);
  const account = useHaven((s) => s.account);
  const setAccountEmail = useHaven((s) => s.setAccountEmail);
  const setPassword = useHaven((s) => s.setPassword);
  const setTwoFactor = useHaven((s) => s.setTwoFactor);
  const [email, setEmail] = useState(account?.email ?? "");
  const [password, setPasswordField] = useState("");
  const [code, setCode] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");

  const submit = () => {
    setError("");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("Enter a valid Apple ID email.");
      return;
    }
    if (password.trim().length < 6) {
      setError("Enter the password. Haven does not save it.");
      return;
    }
    setAccountEmail(email, code.trim().length > 0);
    setPassword(password);
    setTwoFactor(code);
    go("choose");
  };

  return (
    <>
      <NavBar title="Apple ID" onBack={back} />
      <ScreenBody>
        <h2 className="mt-1 font-display text-[28px] font-medium leading-tight tracking-[-0.03em]">
          Sign in on this iPhone.
        </h2>
        <p className="mt-2 text-[14px] leading-relaxed text-fg-muted">
          Used only to sign SideStore. Nothing is sent to Haven. The password stays in memory until
          install finishes, then it is discarded.
        </p>
        <form
          className="mt-6 space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <label className="block">
            <span className="mb-1.5 block text-[12px] font-medium text-fg-muted">Apple ID</span>
            <Input
              autoComplete="username"
              inputMode="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@icloud.com"
            />
          </label>
          <div>
            <span className="mb-1.5 block text-[12px] font-medium text-fg-muted">Password</span>
            <div className="relative">
              <Input
                type={show ? "text" : "password"}
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPasswordField(e.target.value)}
                placeholder="Not stored after signing"
                className="pr-12"
                aria-label="Password"
              />
              <button
                type="button"
                className="absolute top-0 right-0 flex h-12 w-12 items-center justify-center text-fg-muted"
                onClick={() => setShow((v) => !v)}
                aria-label={show ? "Hide password" : "Show password"}
              >
                {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
          </div>
          <label className="block">
            <span className="mb-1.5 block text-[12px] font-medium text-fg-muted">
              Two-factor code (optional)
            </span>
            <Input
              inputMode="numeric"
              autoComplete="one-time-code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="If Apple sends a code"
            />
          </label>
          {error ? <p className="text-[13px] text-danger">{error}</p> : null}
        </form>
        <p className="mt-4 text-[12px] leading-relaxed text-fg-subtle">
          Prefer a spare Apple ID if you do not want to use your main account. Two-factor is normal
          and stays on the phone.
        </p>
      </ScreenBody>
      <BottomBar>
        <PrimaryButton onClick={submit}>Save on this iPhone</PrimaryButton>
      </BottomBar>
    </>
  );
}

export function ChooseScreen() {
  const go = useHaven((s) => s.go);
  const back = useHaven((s) => s.back);
  const kind = useHaven((s) => s.packageKind);
  const setKind = useHaven((s) => s.setPackageKind);
  const setImportedFile = useHaven((s) => s.setImportedFile);
  const importedFileName = useHaven((s) => s.importedFileName);

  return (
    <>
      <NavBar title="Install" onBack={back} />
      <ScreenBody>
        <h2 className="mt-1 font-display text-[28px] font-medium leading-tight tracking-[-0.03em]">
          What should Haven install?
        </h2>
        <p className="mt-2 text-[14px] leading-relaxed text-fg-muted">
          Both options use official GitHub builds. After the first download, Haven can reuse the
          copy on this phone.
        </p>
        <div className="mt-5 space-y-3">
          {(Object.keys(PACKAGES) as PackageKind[]).map((id) => {
            const pkg = PACKAGES[id];
            const selected = kind === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => setKind(id)}
                className={cn(
                  "w-full rounded-[var(--radius-lg)] p-4 text-left shadow-[var(--shadow-border)] transition-colors duration-[var(--motion-quick)]",
                  selected ? "bg-primary text-primary-foreground" : "bg-surface text-fg",
                )}
              >
                <p className="text-[16px] font-semibold">{pkg.short}</p>
                <p className={cn("mt-1 text-[13px] leading-relaxed", selected ? "text-primary-foreground/80" : "text-fg-muted")}>
                  {pkg.description}
                </p>
                <p className={cn("mt-3 text-[11px] font-medium tracking-wide uppercase", selected ? "text-primary-foreground/70" : "text-primary")}>
                  {pkg.slots}
                </p>
              </button>
            );
          })}
        </div>
        <label className="mt-5 flex cursor-pointer items-center gap-3 rounded-[var(--radius-lg)] bg-surface px-4 py-3.5 shadow-[var(--shadow-border)]">
          <FileUp className="size-4 shrink-0 text-primary" />
          <span className="min-w-0">
            <span className="block text-[14px] font-semibold">Use an IPA from Files</span>
            <span className="block truncate text-[12px] text-fg-muted">
              {importedFileName ?? "Optional. Helpful if GitHub is blocked."}
            </span>
          </span>
          <input
            type="file"
            accept=".ipa,application/octet-stream"
            className="sr-only"
            onChange={(e) => setImportedFile(e.target.files?.[0] ?? null)}
          />
        </label>
      </ScreenBody>
      <BottomBar>
        <PrimaryButton onClick={() => go("pair")}>Continue</PrimaryButton>
      </BottomBar>
    </>
  );
}

export function PairScreen() {
  const go = useHaven((s) => s.go);
  const back = useHaven((s) => s.back);
  const pairing = useHaven((s) => s.pairing);
  const pairDevice = useHaven((s) => s.pairDevice);
  const startInstall = useHaven((s) => s.startInstall);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const pair = async () => {
    setBusy(true);
    setError("");
    try {
      await pairDevice();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create a pairing file.");
    } finally {
      setBusy(false);
    }
  };

  const install = async () => {
    setBusy(true);
    setError("");
    try {
      if (!pairing) await pairDevice();
      await startInstall();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not start install.");
      setBusy(false);
    }
  };

  return (
    <>
      <NavBar title="Pairing" onBack={back} />
      <ScreenBody>
        <h2 className="mt-1 font-display text-[28px] font-medium leading-tight tracking-[-0.03em]">
          Pair this iPhone on the phone.
        </h2>
        <p className="mt-2 text-[14px] leading-relaxed text-fg-muted">
          A pairing file replaces the USB cable to a computer. Haven generates it here with a key
          that never leaves the device.
        </p>
        <div className="mt-6 rounded-[var(--radius-lg)] bg-surface p-5 shadow-[var(--shadow-border)]">
          <div className="flex items-center gap-3">
            <div className="flex size-11 items-center justify-center rounded-[var(--radius-md)] bg-primary text-primary-foreground">
              <Smartphone className="size-5" />
            </div>
            <div>
              <p className="text-[15px] font-semibold">This iPhone</p>
              <p className="text-[12px] text-fg-muted">iOS 18 · on-device pairing</p>
            </div>
          </div>
          {pairing ? (
            <dl className="mt-4 space-y-2 text-[13px]">
              <div className="flex justify-between gap-4">
                <dt className="text-fg-muted">Fingerprint</dt>
                <dd className="font-mono tabular-nums">{pairing.fingerprint}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-fg-muted">Created</dt>
                <dd>{new Date(pairing.createdAt).toLocaleString()}</dd>
              </div>
            </dl>
          ) : (
            <p className="mt-4 text-[13px] text-fg-muted">No pairing file yet.</p>
          )}
        </div>
        {error ? <p className="mt-3 text-[13px] text-danger">{error}</p> : null}
        <Button variant="secondary" className="mt-4 w-full" onClick={pair} disabled={busy}>
          {pairing ? "Generate a new pairing file" : "Pair this iPhone"}
        </Button>
      </ScreenBody>
      <BottomBar>
        <PrimaryButton onClick={install} disabled={busy}>
          {busy ? "Working…" : "Pair and install"}
        </PrimaryButton>
      </BottomBar>
    </>
  );
}

export function InstallScreen() {
  const install = useHaven((s) => s.install);
  const go = useHaven((s) => s.go);
  const running = install.status === "running";

  return (
    <>
      <NavBar title="Installing" />
      <ScreenBody>
        <h2 className="mt-1 font-display text-[28px] font-medium leading-tight tracking-[-0.03em]">
          {install.status === "error" ? "Something stopped." : "Haven is working on the phone."}
        </h2>
        <p className="mt-2 text-[14px] text-fg-muted">
          {PACKAGES[install.packageKind].name}
        </p>
        <div className="mt-5 h-1.5 overflow-hidden rounded-full bg-surface-2">
          <div
            className="h-full rounded-full bg-primary transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]"
            style={{ width: `${install.progress}%` }}
          />
        </div>
        <p className="mt-2 text-right font-mono text-[12px] tabular-nums text-fg-muted">
          {install.progress}%
        </p>
        <ol className="mt-4 space-y-1">
          {install.steps.map((step) => (
            <li key={step.id} className="flex items-start gap-3 rounded-[var(--radius-md)] px-1 py-2">
              <StepIcon status={step.status} />
              <span className="min-w-0">
                <span className="block text-[14px] font-medium">{step.label}</span>
                <span className="block text-[12px] leading-relaxed text-fg-muted">{step.detail}</span>
              </span>
            </li>
          ))}
        </ol>
        {install.error ? <p className="mt-3 text-[13px] text-danger">{install.error}</p> : null}
      </ScreenBody>
      {install.status === "error" ? (
        <BottomBar>
          <PrimaryButton onClick={() => go("pair")}>Try again</PrimaryButton>
        </BottomBar>
      ) : null}
      {running ? (
        <p className="sr-only" aria-live="polite">
          Installing, {install.progress} percent
        </p>
      ) : null}
    </>
  );
}

function StepIcon({ status }: { status: string }) {
  if (status === "done") {
    return (
      <span className="mt-0.5 flex size-6 items-center justify-center rounded-full bg-primary text-primary-foreground">
        <Check className="size-3.5" strokeWidth={2.4} />
      </span>
    );
  }
  if (status === "running") {
    return (
      <span className="mt-0.5 flex size-6 items-center justify-center rounded-full bg-surface-2 text-primary">
        <LoaderCircle className="size-3.5 animate-spin" />
      </span>
    );
  }
  if (status === "error") {
    return <span className="mt-0.5 size-6 rounded-full bg-danger/15" />;
  }
  return <span className="mt-0.5 size-6 rounded-full bg-surface-2 shadow-[var(--shadow-border)]" />;
}

export function DoneScreen() {
  const go = useHaven((s) => s.go);
  const pairing = useHaven((s) => s.pairing);
  const kind = useHaven((s) => s.packageKind);
  const packages = useHaven((s) => s.packages);
  const cached = packages.find((p) => p.kind === kind);

  const savePairing = async () => {
    if (!pairing) return;
    const privateKey = await loadStoredPairingPrivateKey();
    downloadJson(`Haven-${pairing.fingerprint}.mobiledevicepairing.json`, pairingFilePayload(pairing, privateKey));
  };

  return (
    <>
      <NavBar title="Ready" />
      <ScreenBody>
        <h2 className="mt-1 font-display text-[28px] font-medium leading-tight tracking-[-0.03em]">
          {PACKAGES[kind].name} is prepared.
        </h2>
        <p className="mt-2 text-[14px] leading-relaxed text-fg-muted">
          Finish in Settings, then open the app. After this, refreshes happen on the phone.
        </p>
        <Group>
          <StepRow n="1" title="Trust the developer" body="Settings → General → VPN & Device Management → trust your Apple ID." />
          <StepRow n="2" title="Turn on Developer Mode" body="Settings → Privacy & Security → Developer Mode. The phone restarts once." />
          <StepRow n="3" title="Connect a loopback VPN" body="Install StosVPN or LocalDevVPN and connect before opening SideStore." />
          <StepRow n="4" title="Refresh once" body="In SideStore, open My Apps and tap the 7-day counter." last />
        </Group>
        <div className="mt-4 flex flex-col gap-2">
          <Button variant="secondary" className="w-full" onClick={savePairing} disabled={!pairing}>
            Save pairing file
          </Button>
          {cached?.sourceUrl ? (
            <Button variant="secondary" className="w-full" asChild>
              <a href={cached.sourceUrl} target="_blank" rel="noreferrer">
                <Download className="size-4" />
                Save official IPA
              </a>
            </Button>
          ) : null}
        </div>
        <p className="mt-4 text-[12px] leading-relaxed text-fg-subtle">
          Docs:{" "}
          <a className="underline" href={OFFICIAL_LINKS.sidestoreDocs} target="_blank" rel="noreferrer">
            SideStore install guide
          </a>
          . Haven is not affiliated with Apple or SideStore.
        </p>
      </ScreenBody>
      <BottomBar>
        <PrimaryButton onClick={() => go("home")}>Go to Haven</PrimaryButton>
      </BottomBar>
    </>
  );
}

function StepRow({
  n,
  title,
  body,
  last,
}: {
  n: string;
  title: string;
  body: string;
  last?: boolean;
}) {
  return (
    <Row last={last}>
      <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-surface-2 font-mono text-[11px] text-primary">
        {n}
      </span>
      <span>
        <span className="block text-[14px] font-semibold">{title}</span>
        <span className="block text-[12px] leading-relaxed text-fg-muted">{body}</span>
      </span>
    </Row>
  );
}
