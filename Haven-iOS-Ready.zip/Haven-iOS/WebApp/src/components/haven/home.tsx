import {
  ChevronRight,
  Fingerprint,
  Info,
  KeyRound,
  Lock,
  RotateCcw,
  ScrollText,
  Shield,
} from "lucide-react";
import { HavenMark } from "@/components/haven/mark";
import { BottomBar, Group, NavBar, PrimaryButton, Row, ScreenBody } from "@/components/haven/shell";
import { Button } from "@/components/ui/button";
import { PACKAGES } from "@/lib/haven/constants";
import { downloadJson, loadStoredPairingPrivateKey, pairingFilePayload } from "@/lib/haven/pairing";
import { useHaven } from "@/lib/haven/store";
import { cn } from "@/lib/utils";

function daysLeft(iso: string | null) {
  if (!iso) return null;
  const ms = new Date(iso).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / (24 * 60 * 60 * 1000)));
}

export function HomeScreen() {
  const go = useHaven((s) => s.go);
  const account = useHaven((s) => s.account);
  const pairing = useHaven((s) => s.pairing);
  const kind = useHaven((s) => s.packageKind);
  const certificates = useHaven((s) => s.certificates);
  const active = certificates.find((c) => c.status === "active");
  const left = daysLeft(active?.expiresAt ?? null);
  const masked = account?.email ? maskEmail(account.email) : "Not signed in";

  return (
    <>
      <ScreenBody className="pt-2">
        <div className="flex items-center gap-3">
          <HavenMark className="size-11 rounded-[14px]" />
          <div>
            <p className="font-display text-[22px] font-medium italic leading-none">Haven</p>
            <p className="mt-1 text-[12px] text-fg-muted">On this iPhone · iOS 18</p>
          </div>
        </div>
        <div className="mt-5 rounded-[var(--radius-xl)] bg-primary p-5 text-primary-foreground">
          <p className="text-[12px] tracking-wide uppercase opacity-70">Prepared</p>
          <p className="mt-1 font-display text-[26px] font-medium leading-tight">{PACKAGES[kind].name}</p>
          <p className="mt-2 text-[13px] leading-relaxed opacity-80">
            {left === null
              ? "Install when you are ready. Pairing and Apple ID stay on the device."
              : `Development certificate · ${left} day${left === 1 ? "" : "s"} left`}
          </p>
          <Button
            variant="secondary"
            className="mt-4 bg-primary-foreground text-primary hover:bg-primary-foreground/90"
            onClick={() => go("choose")}
          >
            Install again
          </Button>
        </div>
        <p className="mt-6 mb-2 px-1 text-[12px] font-medium tracking-wide text-fg-subtle uppercase">
          On device
        </p>
        <Group>
          <Row onClick={() => go("account")}>
            <KeyRound className="size-4 text-primary" />
            <span className="flex-1">
              <span className="block text-[14px] font-semibold">Apple ID</span>
              <span className="block text-[12px] text-fg-muted">{masked}</span>
            </span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
          <Row onClick={() => go("package")}>
            <Fingerprint className="size-4 text-primary" />
            <span className="flex-1">
              <span className="block text-[14px] font-semibold">Pairing</span>
              <span className="block text-[12px] text-fg-muted">
                {pairing ? pairing.fingerprint : "Not paired yet"}
              </span>
            </span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
          <Row onClick={() => go("certificates")}>
            <Shield className="size-4 text-primary" />
            <span className="flex-1">
              <span className="block text-[14px] font-semibold">Certificates</span>
              <span className="block text-[12px] text-fg-muted">3 free app slots</span>
            </span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
          <Row onClick={() => go("activity")} last>
            <ScrollText className="size-4 text-primary" />
            <span className="flex-1">
              <span className="block text-[14px] font-semibold">Activity</span>
              <span className="block text-[12px] text-fg-muted">Local log only</span>
            </span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
        </Group>
        <p className="mt-6 mb-2 px-1 text-[12px] font-medium tracking-wide text-fg-subtle uppercase">
          About
        </p>
        <Group>
          <Row onClick={() => go("privacy")}>
            <Lock className="size-4 text-primary" />
            <span className="flex-1 text-[14px] font-semibold">Privacy</span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
          <Row onClick={() => go("help")} last>
            <Info className="size-4 text-primary" />
            <span className="flex-1 text-[14px] font-semibold">Help</span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
        </Group>
      </ScreenBody>
    </>
  );
}

function maskEmail(email: string) {
  const [user, domain] = email.split("@");
  if (!domain) return email;
  const keep = user.slice(0, 1);
  return `${keep}•••@${domain}`;
}

export function AccountScreen() {
  const back = useHaven((s) => s.back);
  const go = useHaven((s) => s.go);
  const account = useHaven((s) => s.account);
  const forget = useHaven((s) => s.forgetAccount);

  return (
    <>
      <NavBar title="Apple ID" onBack={back} />
      <ScreenBody>
        <Group>
          <Row>
            <span className="flex-1">
              <span className="block text-[12px] text-fg-muted">Signed in as</span>
              <span className="block text-[15px] font-semibold">{account?.email ?? "None"}</span>
            </span>
          </Row>
          <Row last>
            <span className="flex-1">
              <span className="block text-[12px] text-fg-muted">Password</span>
              <span className="block text-[15px] font-semibold">Never saved to disk</span>
            </span>
          </Row>
        </Group>
        <p className="mt-4 text-[13px] leading-relaxed text-fg-muted">
          Haven does not have an account system. Forgetting the Apple ID only clears it from this
          phone.
        </p>
      </ScreenBody>
      <BottomBar>
        <div className="flex flex-col gap-2">
          <PrimaryButton onClick={() => go("signin")}>Change Apple ID</PrimaryButton>
          <Button variant="ghost" className="w-full text-danger" onClick={forget} disabled={!account}>
            Forget Apple ID
          </Button>
        </div>
      </BottomBar>
    </>
  );
}

export function PairingManageScreen() {
  const back = useHaven((s) => s.back);
  const pairing = useHaven((s) => s.pairing);
  const pairDevice = useHaven((s) => s.pairDevice);
  const packages = useHaven((s) => s.packages);

  const save = async () => {
    if (!pairing) return;
    const privateKey = await loadStoredPairingPrivateKey();
    downloadJson(`Haven-${pairing.fingerprint}.mobiledevicepairing.json`, pairingFilePayload(pairing, privateKey));
  };

  return (
    <>
      <NavBar title="Pairing" onBack={back} />
      <ScreenBody>
        <Group>
          <Row>
            <span className="flex-1">
              <span className="block text-[12px] text-fg-muted">Fingerprint</span>
              <span className="block font-mono text-[14px]">{pairing?.fingerprint ?? "—"}</span>
            </span>
          </Row>
          <Row>
            <span className="flex-1">
              <span className="block text-[12px] text-fg-muted">Created</span>
              <span className="block text-[14px]">
                {pairing ? new Date(pairing.createdAt).toLocaleString() : "—"}
              </span>
            </span>
          </Row>
          <Row last>
            <span className="flex-1">
              <span className="block text-[12px] text-fg-muted">iOS</span>
              <span className="block text-[14px]">{pairing?.iosVersion ?? "18"}</span>
            </span>
          </Row>
        </Group>
        {packages.length ? (
          <>
            <p className="mt-6 mb-2 px-1 text-[12px] font-medium tracking-wide text-fg-subtle uppercase">
              Cached packages
            </p>
            <Group>
              {packages.map((p, i) => (
                <Row key={p.kind} last={i === packages.length - 1}>
                  <span className="flex-1">
                    <span className="block text-[14px] font-semibold">{p.name}</span>
                    <span className="block text-[12px] text-fg-muted">
                      {p.version} · {p.sizeLabel} · {p.hasBlob ? "offline copy" : "link saved"}
                    </span>
                  </span>
                </Row>
              ))}
            </Group>
          </>
        ) : null}
      </ScreenBody>
      <BottomBar>
        <div className="flex flex-col gap-2">
          <PrimaryButton onClick={save} disabled={!pairing}>
            Save pairing file
          </PrimaryButton>
          <Button variant="secondary" className="w-full" onClick={() => void pairDevice()}>
            <RotateCcw className="size-4" />
            Pair again
          </Button>
        </div>
      </BottomBar>
    </>
  );
}

export function CertificatesScreen() {
  const back = useHaven((s) => s.back);
  const certificates = useHaven((s) => s.certificates);

  return (
    <>
      <NavBar title="Certificates" onBack={back} />
      <ScreenBody>
        <p className="text-[14px] leading-relaxed text-fg-muted">
          Free Apple IDs can sign three apps. Haven tracks slots on this phone so you can see what
          is using the limit.
        </p>
        <div className="mt-4 space-y-3">
          {certificates.map((slot, i) => (
            <div key={slot.id} className="rounded-[var(--radius-lg)] bg-surface p-4 shadow-[var(--shadow-border)]">
              <p className="text-[12px] text-fg-subtle">Slot {i + 1}</p>
              <p className="mt-1 text-[16px] font-semibold">{slot.name}</p>
              {slot.bundleId ? (
                <p className="mt-1 font-mono text-[12px] text-fg-muted">{slot.bundleId}</p>
              ) : (
                <p className="mt-1 text-[12px] text-fg-muted">Available</p>
              )}
              {slot.expiresAt ? (
                <p className="mt-2 text-[12px] text-warn">
                  Expires {new Date(slot.expiresAt).toLocaleDateString()} · refresh in SideStore
                </p>
              ) : null}
            </div>
          ))}
        </div>
      </ScreenBody>
    </>
  );
}

export function ActivityScreen() {
  const back = useHaven((s) => s.back);
  const activity = useHaven((s) => s.activity);

  return (
    <>
      <NavBar title="Activity" onBack={back} />
      <ScreenBody>
        {activity.length === 0 ? (
          <p className="text-[14px] text-fg-muted">Nothing logged yet. Installs and pairing show up here.</p>
        ) : (
          <ol className="space-y-3">
            {activity.map((event) => (
              <li key={event.id} className="rounded-[var(--radius-lg)] bg-surface p-4 shadow-[var(--shadow-border)]">
                <div className="flex items-center justify-between gap-3">
                  <p className="text-[14px] font-semibold">{event.title}</p>
                  <span
                    className={cn(
                      "text-[11px] font-medium",
                      event.tone === "ok" && "text-ok",
                      event.tone === "warn" && "text-warn",
                      event.tone === "error" && "text-danger",
                      event.tone === "info" && "text-fg-subtle",
                    )}
                  >
                    {new Date(event.at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
                  </span>
                </div>
                <p className="mt-1 text-[12px] leading-relaxed text-fg-muted">{event.detail}</p>
              </li>
            ))}
          </ol>
        )}
      </ScreenBody>
    </>
  );
}

export function PrivacyScreen() {
  const back = useHaven((s) => s.back);
  return (
    <>
      <NavBar title="Privacy" onBack={back} />
      <ScreenBody>
        <h2 className="font-display text-[26px] font-medium leading-tight tracking-[-0.03em]">
          Nothing leaves this iPhone.
        </h2>
        <ul className="mt-5 space-y-3 text-[14px] leading-relaxed text-fg-muted">
          <li>Apple ID email is stored in this browser on this device. You can forget it.</li>
          <li>The password is never written to disk. It is held in memory during signing only.</li>
          <li>Pairing keys are created with Web Crypto and kept in IndexedDB on this phone.</li>
          <li>Official IPAs are fetched from GitHub and can be cached for offline installs.</li>
          <li>Haven has no analytics, no accounts, and no credential server.</li>
        </ul>
      </ScreenBody>
    </>
  );
}

export function HelpScreen() {
  const back = useHaven((s) => s.back);
  const go = useHaven((s) => s.go);
  return (
    <>
      <NavBar title="Help" onBack={back} />
      <ScreenBody>
        <Group>
          <Row onClick={() => go("how")}>
            <span className="flex-1 text-[14px] font-semibold">How Haven works</span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
          <Row onClick={() => go("safety")}>
            <span className="flex-1 text-[14px] font-semibold">Warnings</span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
          <Row onClick={() => go("requirements")} last>
            <span className="flex-1 text-[14px] font-semibold">Requirements</span>
            <ChevronRight className="size-4 text-fg-subtle" />
          </Row>
        </Group>
        <p className="mt-5 text-[13px] leading-relaxed text-fg-muted">
          After SideStore is on the phone, connect a loopback VPN (StosVPN or LocalDevVPN), then
          refresh from My Apps. Pairing files can expire after an iOS update — generate a new one
          here if SideStore asks.
        </p>
        <p className="mt-3 text-[13px] leading-relaxed text-fg-muted">
          Haven is open source, privacy-first, and built for iOS 18. It is not affiliated with Apple
          or the SideStore project.
        </p>
      </ScreenBody>
    </>
  );
}

