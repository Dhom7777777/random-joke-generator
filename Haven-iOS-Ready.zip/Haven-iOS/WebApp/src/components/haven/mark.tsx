export function HavenMark({ className = "size-16" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <rect width="64" height="64" rx="18" fill="var(--color-primary)" />
      <path
        d="M14 38c8-12 28-12 36 0"
        fill="none"
        stroke="var(--color-primary-foreground)"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      <path
        d="M20 42c6-8 18-8 24 0"
        fill="none"
        stroke="var(--color-primary-foreground)"
        strokeWidth="2.4"
        strokeLinecap="round"
        opacity="0.7"
      />
      <circle cx="32" cy="24" r="4.2" fill="var(--color-primary-foreground)" />
    </svg>
  );
}
