import { ChevronLeft } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

function useClock() {
  const [time, setTime] = useState(() =>
    new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }),
  );
  useEffect(() => {
    const tick = () =>
      setTime(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);
  return time;
}

export function StatusBar() {
  const time = useClock();
  return (
    <div className="flex h-11 shrink-0 items-end px-6 pb-1 text-[13px] font-semibold tabular-nums text-fg">
      <span className="w-16">{time}</span>
      <span className="mx-auto h-2.5 w-[108px] rounded-full bg-fg/80" aria-hidden="true" />
      <span className="flex w-16 items-center justify-end gap-1.5">
        <Signal />
        <Battery />
      </span>
    </div>
  );
}

function Signal() {
  return (
    <svg viewBox="0 0 18 12" className="h-3 w-[18px]" aria-hidden="true">
      <rect x="0" y="8" width="3" height="4" rx="0.6" fill="currentColor" />
      <rect x="5" y="5" width="3" height="7" rx="0.6" fill="currentColor" />
      <rect x="10" y="2.5" width="3" height="9.5" rx="0.6" fill="currentColor" />
      <rect x="15" y="0" width="3" height="12" rx="0.6" fill="currentColor" opacity="0.35" />
    </svg>
  );
}

function Battery() {
  return (
    <svg viewBox="0 0 27 12" className="h-3 w-[27px]" aria-hidden="true">
      <rect x="0.5" y="0.5" width="22" height="11" rx="3" fill="none" stroke="currentColor" strokeWidth="1" />
      <rect x="2.2" y="2.2" width="16" height="7.6" rx="1.6" fill="currentColor" />
      <path d="M23.5 4h1.4c.9 0 1.6.7 1.6 1.6v.8c0 .9-.7 1.6-1.6 1.6H23.5" fill="currentColor" opacity="0.45" />
    </svg>
  );
}

export function PhoneFrame({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-dvh items-stretch justify-center bg-bg-deep md:items-center md:px-6 md:py-8">
      <div
        className={cn(
          "relative flex h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-bg",
          "md:h-[min(844px,calc(100dvh-48px))] md:rounded-[var(--radius-2xl)] md:shadow-[var(--shadow-border),0_24px_60px_-28px_rgba(28,27,24,0.35)]",
        )}
      >
        <StatusBar />
        <div className="flex min-h-0 flex-1 flex-col">{children}</div>
        <div className="flex h-5 shrink-0 items-start justify-center pb-1 md:h-6">
          <span className="h-1 w-28 rounded-full bg-fg/25" />
        </div>
      </div>
    </div>
  );
}

export function NavBar({
  title,
  onBack,
  trailing,
}: {
  title?: string;
  onBack?: () => void;
  trailing?: ReactNode;
}) {
  return (
    <div className="flex h-12 shrink-0 items-center px-3">
      {onBack ? (
        <button
          type="button"
          onClick={onBack}
          className="flex size-11 items-center justify-center rounded-[var(--radius-md)] text-fg hover:bg-surface-2"
          aria-label="Back"
        >
          <ChevronLeft className="size-6" strokeWidth={1.8} />
        </button>
      ) : (
        <span className="size-11" />
      )}
      <h1 className="flex-1 text-center text-[15px] font-semibold tracking-tight">{title}</h1>
      <div className="flex size-11 items-center justify-center">{trailing}</div>
    </div>
  );
}

export function ScreenBody({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("min-h-0 flex-1 overflow-y-auto px-5 pb-4", className)}>{children}</div>
  );
}

export function BottomBar({ children }: { children: ReactNode }) {
  return (
    <div className="shrink-0 border-t border-border bg-bg/90 px-5 pt-3 pb-[max(12px,env(safe-area-inset-bottom))] backdrop-blur-sm">
      {children}
    </div>
  );
}

export function PrimaryButton({
  children,
  onClick,
  disabled,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  return (
    <Button type={type} size="lg" className="w-full" onClick={onClick} disabled={disabled}>
      {children}
    </Button>
  );
}

export function Group({ children }: { children: ReactNode }) {
  return (
    <div className="overflow-hidden rounded-[var(--radius-lg)] bg-surface shadow-[var(--shadow-border)]">
      {children}
    </div>
  );
}

export function Row({
  children,
  onClick,
  last,
}: {
  children: ReactNode;
  onClick?: () => void;
  last?: boolean;
}) {
  const className = cn(
    "flex w-full items-center gap-3 px-4 py-3.5 text-left",
    !last && "border-b border-border",
    onClick && "hover:bg-surface-2",
  );
  if (onClick) {
    return (
      <button type="button" className={className} onClick={onClick}>
        {children}
      </button>
    );
  }
  return <div className={className}>{children}</div>;
}
