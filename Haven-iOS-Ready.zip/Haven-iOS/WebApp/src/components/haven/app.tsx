import { AccountScreen, ActivityScreen, CertificatesScreen, HelpScreen, HomeScreen, PairingManageScreen, PrivacyScreen } from "@/components/haven/home";
import { ChooseScreen, DoneScreen, InstallScreen, PairScreen, SignInScreen } from "@/components/haven/setup";
import { HowScreen, RequirementsScreen, SafetyScreen, WelcomeScreen } from "@/components/haven/onboarding";
import { PhoneFrame } from "@/components/haven/shell";
import { useHaven } from "@/lib/haven/store";

export function HavenApp() {
  const screen = useHaven((s) => s.screen);

  return (
    <PhoneFrame>
      {screen === "welcome" && <WelcomeScreen />}
      {screen === "how" && <HowScreen />}
      {screen === "safety" && <SafetyScreen />}
      {screen === "requirements" && <RequirementsScreen />}
      {screen === "signin" && <SignInScreen />}
      {screen === "choose" && <ChooseScreen />}
      {screen === "pair" && <PairScreen />}
      {screen === "install" && <InstallScreen />}
      {screen === "done" && <DoneScreen />}
      {screen === "home" && <HomeScreen />}
      {screen === "account" && <AccountScreen />}
      {screen === "package" && <PairingManageScreen />}
      {screen === "certificates" && <CertificatesScreen />}
      {screen === "activity" && <ActivityScreen />}
      {screen === "privacy" && <PrivacyScreen />}
      {screen === "help" && <HelpScreen />}
    </PhoneFrame>
  );
}
