import { Check, Lock, RefreshCw, Shield } from "lucide-react";
import type { ReactNode } from "react";
import { HavenMark } from "@/components/haven/mark";
import { BottomBar, NavBar, PrimaryButton, ScreenBody } from "@/components/haven/shell";
import { HOW_STEPS, REQUIREMENTS } from "@/lib/haven/constants";
import { useHaven } from "@/lib/haven/store";
import { cn } from "@/lib/utils";

export function WelcomeScreen() {
  const go = useHaven((s) => s.go);
  const setupComplete = useHaven((s) => s.setupComplete);
  return (
    <>
      <ScreenBody className="flex flex-col">
        <div className="flex flex-1 flex-col justify-center py-6">
          <HavenMark className="haven-enter size-[72px] rounded-[22px]" />
          <p className="haven-enter haven-enter-2 mt-8 font-display text-[15px] italic text-primary">
            Haven
          </p>
          <h1 className="haven-enter haven-enter-3 mt-2 max-w-[16ch] font-display text-[34px] font-medium leading-[1.12] tracking-[-0.03em] text-fg">
            SideStore, on this iPhone.
          </h1>
          <p className="haven-enter haven-enter-4 mt-4 max-w-[34ch] text-[15px] leading-relaxed text-fg-muted">
            Pair, sign, and install SideStore or LiveContainer without a Mac or PC. Your Apple ID
            never leaves the phone.
          </p>
        </div>
        <p className="haven-enter haven-enter-5 pb-3 text-center text-[12px] text-fg-subtle">
          Open source · Offline after first setup · iOS 18
        </p>
      </ScreenBody>
      <BottomBar>
        <PrimaryButton onClick={() => go(setupComplete ? "home" : "how")}>Get started</PrimaryButton>
      </BottomBar>
    </>
  );
}

export function HowScreen() {
  const go = useHaven((s) => s.go);
  const back = useHaven((s) => s.back);
  return (
    <>
      <NavBar title="How it works" onBack={back} />
      <ScreenBody>
        <h2 className="haven-enter mt-1 font-display text-[28px] font-medium leading-tight tracking-[-0.03em]">
          Four quiet steps. Then you’re done.
        </h2>
        <ol className="mt-6 space-y-3">
          {HOW_STEPS.map((step, i) => (
            <li
              key={step.n}
              className={cn("haven-enter rounded-[var(--radius-lg)] bg-surface p-4 shadow-[var(--shadow-border)]", i === 1 && "haven-enter-2", i === 2 && "haven-enter-3", i === 3 && "haven-enter-4")}
            >
              <p className="font-mono text-[11px] tracking-wide text-primary">{step.n}</p>
              <p className="mt-1 text-[15px] font-semibold">{step.title}</p>
              <p className="mt-1 text-[13px] leading-relaxed text-fg-muted">{step.body}</p>
            </li>
          ))}
        </ol>
      </ScreenBody>
      <BottomBar>
        <PrimaryButton onClick={() => go("safety")}>Continue</PrimaryButton>
      </BottomBar>
    </>
  );
}

export function SafetyScreen() {
  const go = useHaven((s) => s.go);
  const back = useHaven((s) => s.back);
  return (
    <>
      <NavBar title="Please read" onBack={back} />
      <ScreenBody>
        <h2 className="mt-1 font-display text-[28px] font-medium leading-tight tracking-[-0.03em]">
          Safe, with a few honest limits.
        </h2>
        <div className="mt-6 space-y-3">
          <SafetyCard
            icon={<Lock className="size-4" />}
            title="Your Apple ID stays here"
            body="Haven has no login servers. The password is held in memory while signing, then discarded. The email can be forgotten any time."
          />
          <SafetyCard
            icon={<RefreshCw className="size-4" />}
            title="Free apps last 7 days"
            body="Apple’s free developer certificate expires every week. After setup, SideStore can refresh itself on the phone. You do not need a computer for that."
          />
          <SafetyCard
            icon={<Shield className="size-4" />}
            title="Three apps, your responsibility"
            body="A free Apple ID can install three apps at once. Haven is not Apple and not SideStore. Only install software you trust."
          />
        </div>
        <p className="mt-5 text-[12px] leading-relaxed text-fg-subtle">
          A website cannot place an icon on the Home Screen by itself. Haven prepares pairing and
          signing on this device, then you trust the developer app in Settings — the same last step
          every sideloaded app uses.
        </p>
      </ScreenBody>
      <BottomBar>
        <PrimaryButton onClick={() => go("requirements")}>I understand</PrimaryButton>
      </BottomBar>
    </>
  );
}

function SafetyCard({
  icon,
  title,
  body,
}: {
  icon: ReactNode;
  title: string;
  body: string;
}) {
  return (
    <div className="flex gap-3 rounded-[var(--radius-lg)] bg-surface p-4 shadow-[var(--shadow-border)]">
      <div className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-[var(--radius-sm)] bg-primary text-primary-foreground">
        {icon}
      </div>
      <div>
        <p className="text-[15px] font-semibold">{title}</p>
        <p className="mt-1 text-[13px] leading-relaxed text-fg-muted">{body}</p>
      </div>
    </div>
  );
}

export function RequirementsScreen() {
  const go = useHaven((s) => s.go);
  const back = useHaven((s) => s.back);
  const requirements = useHaven((s) => s.requirements);
  const toggle = useHaven((s) => s.toggleRequirement);
  const ready = REQUIREMENTS.every((r) => requirements[r.id]);

  return (
    <>
      <NavBar title="Before you begin" onBack={back} />
      <ScreenBody>
        <h2 className="mt-1 font-display text-[28px] font-medium leading-tight tracking-[-0.03em]">
          Check these on your iPhone.
        </h2>
        <p className="mt-2 text-[14px] leading-relaxed text-fg-muted">
          Tap each item you can do. Haven will not skip this list — it keeps first-time setup from
          failing halfway through.
        </p>
        <ul className="mt-5 overflow-hidden rounded-[var(--radius-lg)] bg-surface shadow-[var(--shadow-border)]">
          {REQUIREMENTS.map((item, i) => {
            const on = requirements[item.id];
            return (
              <li key={item.id} className={i < REQUIREMENTS.length - 1 ? "border-b border-border" : ""}>
                <button
                  type="button"
                  onClick={() => toggle(item.id)}
                  className="flex w-full items-start gap-3 px-4 py-3.5 text-left"
                >
                  <span
                    className={cn(
                      "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full transition-colors duration-[var(--motion-quick)]",
                      on ? "bg-primary text-primary-foreground" : "bg-surface-2 text-transparent shadow-[var(--shadow-border)]",
                    )}
                  >
                    <Check className="size-3.5" strokeWidth={2.4} />
                  </span>
                  <span>
                    <span className="block text-[15px] font-semibold">{item.title}</span>
                    <span className="mt-0.5 block text-[12px] leading-relaxed text-fg-muted">
                      {item.body}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </ScreenBody>
      <BottomBar>
        <PrimaryButton disabled={!ready} onClick={() => go("signin")}>
          {ready ? "Continue" : "Check every item"}
        </PrimaryButton>
      </BottomBar>
    </>
  );
}
