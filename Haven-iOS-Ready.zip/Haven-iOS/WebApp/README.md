# Haven

Install SideStore and LiveContainer on an iPhone, without a Mac or PC.

Haven is a privacy-first, open-source setup app for iOS 18. Pairing keys and Apple ID credentials stay on the device. After the first download, official IPAs can be reused offline.

## What it does

- Walks a first-time user through requirements, warnings, and Apple ID sign-in
- Stores the Apple ID locally; the password is held in memory only while signing
- Generates an on-device pairing file (Web Crypto, P-256)
- Installs **SideStore** or **SideStore + LiveContainer**
- Shows live progress for pairing, signing, and install
- Tracks the three free certificate slots and a local activity log

Haven is not affiliated with Apple or SideStore.

## Privacy

- No Haven accounts, analytics, or credential servers
- Pairing private keys live in IndexedDB on this phone
- Cached IPAs stay on this phone
- Forget Apple ID at any time

## License

Source in this repository is provided for personal, non-commercial use. Official SideStore and LiveContainer builds remain under their own licenses.
