import SwiftUI
import WebKit

struct ContentView: View {
    var body: some View {
        HavenWebView()
            .ignoresSafeArea()
    }
}

struct HavenWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        // Allow local file access for bundled web assets
        if #available(iOS 16.4, *) {
            config.preferences.isElementFullscreenEnabled = true
        }

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .clear

        // iOS 15 scroll bounce
        if #available(iOS 16.0, *) {
            webView.scrollView.bounces = false
        }

        // Load bundled web app; fall back to error page
        if let index = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "WebApp") {
            webView.loadFileURL(index, allowingReadAccessTo: index.deletingLastPathComponent())
        } else {
            let html = """
            <!DOCTYPE html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
              <style>
                body { font-family: -apple-system, sans-serif; background: #EFECE6;
                       display: flex; flex-direction: column; align-items: center;
                       justify-content: center; height: 100vh; margin: 0; padding: 24px;
                       box-sizing: border-box; text-align: center; }
                h2 { font-size: 22px; font-weight: 600; margin-bottom: 12px; }
                p  { font-size: 15px; color: #555; line-height: 1.5; }
                code { background: #e0ddd7; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
              </style>
            </head>
            <body>
              <h2>Haven — Web assets missing</h2>
              <p>Run <code>Scripts/build-web.sh</code> from the project root,
                 then rebuild in Xcode.</p>
            </body>
            </html>
            """
            webView.loadHTMLString(html, baseURL: nil)
        }
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        // Handle target=_blank links
        func webView(_ webView: WKWebView,
                     createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction,
                     windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url {
                webView.load(URLRequest(url: url))
            }
            return nil
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            print("[Haven] Navigation error: \(error.localizedDescription)")
        }
    }
}
