# Haven iOS — Build & Sideload Guide

Wraps the Haven web app in a native WKWebView for iOS 15.0 – 18.x.

---

## Requirements

- macOS with **Xcode 15+**
- **Node.js 18+** (for building the web assets)
- A free or paid Apple Developer account
- [zsign](https://github.com/zhlynn/zsign) or [AltSign](https://github.com/rileytestut/AltSign) if signing outside Xcode

---

## Step 1 — Build the web assets

```bash
cd Haven-iOS
bash Scripts/build-web.sh
```

This runs `vite build` inside `WebApp/`, then copies the output into `Haven/WebApp/`.
You should see `Haven/WebApp/index.html` when it finishes.

---

## Step 2 — Open in Xcode

```
open Haven.xcodeproj
```

- Select the **Haven** target → **Signing & Capabilities**
- Set your **Team** (free Apple ID is fine for sideloading)
- Bundle ID is `com.haven.sideload` — change it if needed

---

## Step 3 — Build for device

1. Connect your iPhone
2. Select your device in the toolbar
3. Product → **Build** (⌘B) to confirm it compiles
4. Product → **Archive** to create an archive

---

## Step 4 — Export the IPA

After archiving:

- **Xcode Organizer** → select archive → **Distribute App**
- Choose **Custom** → **Ad Hoc** or **Development**
- Export to a folder — you'll get a `.ipa` file

---

## Step 5 — Sideload with SideStore / AltStore

1. Open **SideStore** on your iPhone
2. Tap **+** → browse to `Haven.ipa`
3. Install and trust in Settings → VPN & Device Management

---

## Deployment target

- Minimum: **iOS 15.0**
- Tested range: iOS 15.8.8 → iOS 18.x
- Set in `Haven.xcodeproj` → Build Settings → `IPHONEOS_DEPLOYMENT_TARGET = 15.0`

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Web assets missing" screen | Run `Scripts/build-web.sh` first |
| Signing error | Set your Team in Signing & Capabilities |
| App crashes on iOS 15 | Check for any `@available(iOS 16)` guards in ContentView |
| `npm ci` fails | Ensure Node 18+ is installed; try `npm install` instead |

