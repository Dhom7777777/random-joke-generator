#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WEB="$ROOT/WebApp"
DEST="$ROOT/Haven/WebApp"
cd "$WEB"
if [ ! -d node_modules ]; then npm ci; fi
VITE_AUTH_ENABLED=false npm run build
rm -rf "$DEST"
mkdir -p "$DEST"
if [ -d dist ]; then cp -R dist/. "$DEST/"; elif [ -d .output/public ]; then cp -R .output/public/. "$DEST/"; else echo 'Could not find static web output (dist or .output/public).' >&2; exit 1; fi
if [ ! -f "$DEST/index.html" ]; then echo 'index.html was not produced.' >&2; exit 1; fi
